import { useState, useRef, useEffect, useCallback } from 'react';
import { GoogleGenAI, GenerateContentResponse, ThinkingLevel, Modality, LiveServerMessage } from "@google/genai";
import { motion, AnimatePresence } from "motion/react";
import ReactMarkdown from 'react-markdown';
import { 
  Send, 
  Image as ImageIcon, 
  X, 
  Loader2, 
  Plus,
  Sparkles,
  User,
  Bot,
  Paperclip,
  Info,
  Github,
  Twitter,
  Search,
  MapPin,
  Brain,
  Mic,
  MicOff,
  Zap,
  ArrowRight,
  Maximize2,
  History,
  Settings,
  ImagePlus,
  ChevronDown,
  Home,
  Sun,
  Moon
} from 'lucide-react';
import { cn } from './lib/utils';

// --- Types ---

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  images?: string[];
  isStreaming?: boolean;
  isThinking?: boolean;
  type?: 'text' | 'image' | 'voice';
}

type AppView = 'landing' | 'conversation' | 'live';

interface VoiceOption {
  id: string;
  name: string;
  gender: 'male' | 'female';
}

const VOICES: VoiceOption[] = [
  { id: 'Puck', name: 'Puck (Male)', gender: 'male' },
  { id: 'Charon', name: 'Charon (Male)', gender: 'male' },
  { id: 'Kore', name: 'Kore (Female)', gender: 'female' },
  { id: 'Fenrir', name: 'Fenrir (Male)', gender: 'male' },
  { id: 'Zephyr', name: 'Zephyr (Neutral)', gender: 'male' },
];

// --- Components ---

const IntroAnimation = ({ onComplete }: { onComplete: () => void }) => {
  return (
    <motion.div 
      initial={{ opacity: 1 }}
      animate={{ opacity: 0 }}
      transition={{ duration: 1, delay: 2.5 }}
      onAnimationComplete={onComplete}
      className="fixed inset-0 z-[200] bg-black flex items-center justify-center"
    >
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 1.5, ease: "easeOut" }}
        className="relative flex flex-col items-center"
      >
        <div className="relative w-64 h-64 flex items-center justify-center">
          <motion.div 
            initial={{ rotate: 0 }}
            animate={{ rotate: 360 }}
            transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
            className="absolute inset-0 border-2 border-purple-500/30 rounded-full shadow-[0_0_50px_rgba(168,85,247,0.4)]"
          />
          <motion.div 
            initial={{ rotate: 0 }}
            animate={{ rotate: -360 }}
            transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
            className="absolute inset-4 border border-blue-500/20 rounded-full"
          />
          <h1 className="text-6xl font-black tracking-widest text-zinc-900 dark:text-white aura-text-glow z-10">
            AURA
          </h1>
        </div>
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1, duration: 0.8 }}
          className="mt-8 text-zinc-500 tracking-[0.3em] text-sm uppercase font-medium"
        >
          Intelligence Redefined
        </motion.p>
      </motion.div>
    </motion.div>
  );
};

const HistoryModal = ({ isOpen, onClose, history }: { isOpen: boolean, onClose: () => void, history: Message[] }) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-white/80 dark:bg-black/80 backdrop-blur-2xl"
          />
          <motion.div 
            initial={{ scale: 0.9, opacity: 0, y: 40 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 40 }}
            className="relative w-full max-w-lg bg-white dark:bg-zinc-950 border border-black/10 dark:border-white/10 rounded-[3rem] overflow-hidden shadow-[0_0_100px_rgba(0,0,0,0.1)] dark:shadow-[0_0_100px_rgba(0,0,0,1)] glow-border"
          >
            <div className="p-10 space-y-8 relative z-10">
              <div className="flex justify-between items-start">
                <div className="space-y-2">
                  <h2 className="text-3xl font-black text-zinc-900 dark:text-white tracking-tighter">History</h2>
                  <p className="text-zinc-500 text-xs font-black uppercase tracking-[0.3em]">Previous Sessions</p>
                </div>
                <button 
                  onClick={onClose}
                  className="p-3 hover:bg-black/5 dark:hover:bg-white/5 rounded-2xl transition-all border border-transparent hover:border-black/10 dark:hover:border-white/10"
                >
                  <X className="w-6 h-6 text-zinc-500" />
                </button>
              </div>

              <div className="max-h-[50vh] overflow-y-auto space-y-4 pr-2 scrollbar-hide">
                {history.length === 0 ? (
                  <div className="text-center py-12 space-y-4">
                    <History className="w-12 h-12 text-zinc-800 mx-auto" />
                    <p className="text-zinc-600 font-bold">No history yet.</p>
                  </div>
                ) : (
                  history.map((item) => (
                    <div key={item.id} className="p-5 bg-black/5 dark:bg-white/5 border border-black/5 dark:border-white/5 rounded-2xl space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-black uppercase tracking-widest text-blue-400">
                          {item.type === 'voice' ? 'Voice Session' : 'Chat Session'}
                        </span>
                        <span className="text-[10px] font-black text-zinc-600">
                          {new Date(parseInt(item.id)).toLocaleTimeString()}
                        </span>
                      </div>
                      <p className="text-sm text-zinc-700 dark:text-zinc-300 line-clamp-2 leading-relaxed">
                        {item.content}
                      </p>
                    </div>
                  ))
                )}
              </div>

              <div className="pt-6 border-t border-black/5 dark:border-white/5">
                <p className="text-[10px] text-zinc-600 text-center font-black uppercase tracking-[0.5em]">
                  AURA v1.0 • History
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

const SettingsModal = ({ 
  isOpen, 
  onClose, 
  selectedVoice, 
  onVoiceChange,
  speechSpeed,
  onSpeedChange
}: { 
  isOpen: boolean, 
  onClose: () => void,
  selectedVoice: string,
  onVoiceChange: (voiceId: string) => void,
  speechSpeed: number,
  onSpeedChange: (speed: number) => void
}) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-white/80 dark:bg-black/80 backdrop-blur-2xl"
          />
          <motion.div 
            initial={{ scale: 0.9, opacity: 0, y: 40 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 40 }}
            className="relative w-full max-w-md bg-white dark:bg-zinc-950 border border-black/10 dark:border-white/10 rounded-[3rem] overflow-hidden shadow-[0_0_100px_rgba(0,0,0,0.1)] dark:shadow-[0_0_100px_rgba(0,0,0,1)] glow-border"
          >
            <div className="p-10 space-y-8 relative z-10">
              <div className="flex justify-between items-start">
                <div className="space-y-2">
                  <h2 className="text-3xl font-black text-zinc-900 dark:text-white tracking-tighter">Settings</h2>
                  <p className="text-zinc-500 text-xs font-black uppercase tracking-[0.3em]">Configure AURA</p>
                </div>
                <button 
                  onClick={onClose}
                  className="p-3 hover:bg-black/5 dark:hover:bg-white/5 rounded-2xl transition-all border border-transparent hover:border-black/10 dark:hover:border-white/10"
                >
                  <X className="w-6 h-6 text-zinc-500" />
                </button>
              </div>

              <div className="space-y-8">
                <div className="space-y-3">
                  <label className="text-[10px] font-black uppercase tracking-[0.3em] text-zinc-500">AI Voice Personality</label>
                  <div className="grid grid-cols-1 gap-2">
                    {VOICES.map((voice) => (
                      <button
                        key={voice.id}
                        onClick={() => onVoiceChange(voice.id)}
                        className={cn(
                          "flex items-center justify-between p-4 rounded-2xl border transition-all",
                          selectedVoice === voice.id 
                            ? "bg-blue-500/10 border-blue-500/30 text-zinc-900 dark:text-white" 
                            : "bg-black/5 dark:bg-white/5 border-black/5 dark:border-white/5 text-zinc-600 dark:text-zinc-400 hover:bg-black/10 dark:hover:bg-white/10"
                        )}
                      >
                        <span className="text-sm font-bold">{voice.name}</span>
                        {selectedVoice === voice.id && <Sparkles className="w-4 h-4 text-blue-400" />}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <label className="text-[10px] font-black uppercase tracking-[0.3em] text-zinc-500">Speech Speed</label>
                    <span className="text-xs font-black text-blue-400">{speechSpeed}x</span>
                  </div>
                  <input 
                    type="range" 
                    min="0.5" 
                    max="2" 
                    step="0.1" 
                    value={speechSpeed}
                    onChange={(e) => onSpeedChange(parseFloat(e.target.value))}
                    className="w-full h-1.5 bg-black/10 dark:bg-white/10 rounded-full appearance-none cursor-pointer accent-blue-500"
                  />
                  <div className="flex justify-between text-[8px] font-black text-zinc-600 uppercase tracking-widest">
                    <span>Slower</span>
                    <span>Normal</span>
                    <span>Faster</span>
                  </div>
                </div>
              </div>

              <div className="pt-6 border-t border-black/5 dark:border-white/5">
                <p className="text-[10px] text-zinc-600 text-center font-black uppercase tracking-[0.5em]">
                  AURA v1.0 • Settings
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

const LiveVisualizer = ({ isActive, volume, status }: { isActive: boolean, volume: number, status: 'listening' | 'thinking' | 'speaking' }) => {
  const getStatusColor = () => {
    switch (status) {
      case 'listening': return 'from-blue-500 via-cyan-500 to-blue-600';
      case 'thinking': return 'from-purple-500 via-pink-500 to-purple-600';
      case 'speaking': return 'from-emerald-500 via-teal-500 to-emerald-600';
      default: return 'from-blue-500 via-purple-500 to-pink-500';
    }
  };

  const getBarColor = () => {
    switch (status) {
      case 'listening': return 'rgba(59, 130, 246,';
      case 'thinking': return 'rgba(168, 85, 247,';
      case 'speaking': return 'rgba(16, 185, 129,';
      default: return 'rgba(59, 130, 246,';
    }
  };

  return (
    <div className="relative w-full h-64 flex items-center justify-center">
      <AnimatePresence>
        {isActive && (
          <>
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ 
                scale: 1 + volume * 2, 
                opacity: 0.1 + volume * 0.5,
                rotate: 360
              }}
              transition={{ 
                scale: { type: "spring", stiffness: 300, damping: 20 },
                rotate: { duration: 20, repeat: Infinity, ease: "linear" }
              }}
              className={cn("absolute w-64 h-64 rounded-full blur-3xl opacity-20 transition-all duration-1000 bg-gradient-to-r", getStatusColor())}
            />
            <motion.div
              animate={{ 
                scale: 1 + volume * 1.5,
                opacity: 0.2 + volume * 0.4,
                rotate: -360
              }}
              transition={{ 
                scale: { type: "spring", stiffness: 200, damping: 25 },
                rotate: { duration: 15, repeat: Infinity, ease: "linear" }
              }}
              className="absolute w-48 h-48 rounded-full border-2 border-white/20"
            />
            <div className="flex items-center gap-1 h-32">
              {[...Array(24)].map((_, i) => (
                <motion.div
                  key={i}
                  animate={{ 
                    height: isActive ? `${20 + Math.random() * 80 * volume}%` : "4px",
                    backgroundColor: isActive ? `${getBarColor()} ${0.3 + volume})` : "rgba(255, 255, 255, 0.1)"
                  }}
                  className="w-1 rounded-full transition-colors duration-500"
                />
              ))}
            </div>
          </>
        )}
      </AnimatePresence>
      {!isActive && (
        <div className="text-zinc-500 font-black uppercase tracking-[0.5em] animate-pulse">
          Connecting to AURA...
        </div>
      )}
    </div>
  );
};

const AboutModal = ({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-white/80 dark:bg-black/80 backdrop-blur-2xl"
          />
          <motion.div 
            initial={{ scale: 0.9, opacity: 0, y: 40 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 40 }}
            className="relative w-full max-w-lg bg-white dark:bg-zinc-950 border border-black/10 dark:border-white/10 rounded-[3rem] overflow-hidden shadow-[0_0_100px_rgba(0,0,0,0.1)] dark:shadow-[0_0_100px_rgba(0,0,0,1)] glow-border"
          >
            <div className="p-10 space-y-8 relative z-10">
              <div className="flex justify-between items-start">
                <div className="space-y-2">
                  <h2 className="text-3xl font-black text-zinc-900 dark:text-white tracking-tighter">The Architect</h2>
                  <p className="text-zinc-500 text-xs font-black uppercase tracking-[0.3em]">Engineering the Future</p>
                </div>
                <button 
                  onClick={onClose}
                  className="p-3 hover:bg-black/5 dark:hover:bg-white/5 rounded-2xl transition-all border border-transparent hover:border-black/10 dark:hover:border-white/10"
                >
                  <X className="w-6 h-6 text-zinc-500" />
                </button>
              </div>

              <div className="flex flex-col sm:flex-row items-center gap-8">
                <div className="relative group">
                  <div className="absolute inset-0 bg-gradient-to-br from-blue-500 via-purple-500 to-pink-500 rounded-[2.5rem] blur-2xl opacity-40 group-hover:opacity-60 transition-opacity" />
                  <div className="relative w-32 h-32 rounded-[2.5rem] bg-zinc-100 dark:bg-zinc-900 border border-black/10 dark:border-white/10 flex items-center justify-center text-5xl font-black text-zinc-900 dark:text-white shadow-2xl overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-br from-blue-600 to-purple-600 opacity-20" />
                    M
                  </div>
                </div>
                <div className="space-y-4 text-center sm:text-left">
                  <h3 className="text-2xl font-black text-zinc-900 dark:text-white">Monish</h3>
                  <p className="text-zinc-600 dark:text-zinc-400 text-base leading-relaxed font-medium">
                    A visionary full-stack developer and AI engineer dedicated to crafting seamless digital experiences that push the boundaries of technology.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <a href="#" className="flex items-center justify-center gap-3 p-5 bg-black/5 dark:bg-white/5 border border-black/5 dark:border-white/5 rounded-2xl hover:bg-black/10 dark:hover:bg-white/10 hover:border-black/10 dark:hover:border-white/10 transition-all group">
                  <Github className="w-5 h-5 text-zinc-500 group-hover:text-zinc-900 dark:group-hover:text-white" />
                  <span className="text-sm font-black uppercase tracking-widest text-zinc-600 dark:text-zinc-400 group-hover:text-zinc-900 dark:group-hover:text-white">GitHub</span>
                </a>
                <a href="#" className="flex items-center justify-center gap-3 p-5 bg-black/5 dark:bg-white/5 border border-black/5 dark:border-white/5 rounded-2xl hover:bg-black/10 dark:hover:bg-white/10 hover:border-black/10 dark:hover:border-white/10 transition-all group">
                  <Twitter className="w-5 h-5 text-zinc-500 group-hover:text-zinc-900 dark:group-hover:text-white" />
                  <span className="text-sm font-black uppercase tracking-widest text-zinc-600 dark:text-zinc-400 group-hover:text-zinc-900 dark:group-hover:text-white">Twitter</span>
                </a>
              </div>

              <div className="pt-6 border-t border-black/5 dark:border-white/5">
                <p className="text-[10px] text-zinc-600 text-center font-black uppercase tracking-[0.5em] italic">
                  "Intelligence is the ultimate frontier."
                </p>
              </div>
            </div>
            
            {/* Background Accent */}
            <div className="absolute -bottom-24 -right-24 w-64 h-64 bg-blue-600/10 rounded-full blur-[100px]" />
            <div className="absolute -top-24 -left-24 w-64 h-64 bg-purple-600/10 rounded-full blur-[100px]" />
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

// --- Main Application ---

export default function App() {
  const [showIntro, setShowIntro] = useState(true);
  const [view, setView] = useState<AppView>('landing');
  const [showAbout, setShowAbout] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [selectedVoice, setSelectedVoice] = useState('Zephyr');
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [selectedImages, setSelectedImages] = useState<string[]>([]);
  
  // Feature Toggles
  const [isThinkingMode, setIsThinkingMode] = useState(false);
  const [isLiveMode, setIsLiveMode] = useState(false);
  const [useSearch, setUseSearch] = useState(false);
  const [useMaps, setUseMaps] = useState(false);
  const [imageSize, setImageSize] = useState<'1K' | '2K' | '4K'>('1K');
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const [micVolume, setMicVolume] = useState(0);
  const [liveTranscription, setLiveTranscription] = useState('');
  const [aiTranscription, setAiTranscription] = useState('');
  const [liveStatus, setLiveStatus] = useState<'listening' | 'thinking' | 'speaking'>('listening');
  const [speechSpeed, setSpeechSpeed] = useState(1);
  const [history, setHistory] = useState<Message[]>([]);
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');

  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark');
  }, [theme]);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const liveSessionRef = useRef<any>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const audioQueueRef = useRef<Int16Array[]>([]);
  const isPlayingRef = useRef(false);

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages, scrollToBottom]);

  // --- Live API Logic ---

  const startLiveMode = async () => {
    try {
      // Check for API key selection for premium models
      if (!(await (window as any).aistudio.hasSelectedApiKey())) {
        await (window as any).aistudio.openSelectKey();
      }

      // Request microphone permission
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const sessionPromise = ai.live.connect({
        model: "gemini-3.1-flash-live-preview",
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: selectedVoice } },
          },
          systemInstruction: "You are AURA, a helpful and ultra-fast AI assistant. You are in a real-time voice conversation. Keep your responses natural, concise, and engaging. Use speech to reply.",
          inputAudioTranscription: {},
          outputAudioTranscription: {},
        },
        callbacks: {
          onopen: () => {
            console.log("Live session opened");
            setIsLiveMode(true);
            setLiveStatus('listening');
            startAudioStreaming(stream, sessionPromise);
          },
          onmessage: async (message: LiveServerMessage) => {
            console.log("Live Message received:", message);
            
            // Handle Transcription
            if (message.serverContent?.modelTurn?.parts) {
              for (const part of message.serverContent.modelTurn.parts) {
                if (part.inlineData?.data) {
                  setLiveStatus('speaking');
                  queueAudio(part.inlineData.data);
                }
              }
            }

            if (message.serverContent?.interrupted) {
              audioQueueRef.current = [];
              isPlayingRef.current = false;
              setLiveStatus('listening');
              setAiTranscription('');
            }

            // Handle Transcriptions from server
            if (message.serverContent?.turnComplete) {
              setLiveStatus('listening');
            }

            // Check for transcription parts
            const modelTurn = message.serverContent?.modelTurn;
            if (modelTurn?.parts) {
              const textPart = modelTurn.parts.find(p => p.text);
              if (textPart?.text) {
                setAiTranscription(prev => prev + textPart.text);
              }
            }

            // Handle user transcription
            // Note: The Live API sends transcription in a specific format
            if ((message as any).serverContent?.inputAudioTranscription?.text) {
              setLiveTranscription((message as any).serverContent.inputAudioTranscription.text);
              setLiveStatus('thinking');
            }
          },
          onclose: () => stopLiveMode(),
          onerror: (err) => {
            console.error("Live Error:", err);
            stopLiveMode();
          },
        }
      });
      const session = await sessionPromise;
      liveSessionRef.current = session;
    } catch (err) {
      console.error("Failed to start Live Mode:", err);
      setIsLiveMode(false);
    }
  };

  const startAudioStreaming = (stream: MediaStream, sessionPromise: Promise<any>) => {
    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
    }
    const context = audioContextRef.current;
    const source = context.createMediaStreamSource(stream);
    const processor = context.createScriptProcessor(4096, 1, 1);
    processorRef.current = processor;

    processor.onaudioprocess = (e) => {
      const inputData = e.inputBuffer.getChannelData(0);
      
      // Calculate volume for visualizer
      let sum = 0;
      for (let i = 0; i < inputData.length; i++) {
        sum += inputData[i] * inputData[i];
      }
      setMicVolume(Math.sqrt(sum / inputData.length));

      // Convert to PCM16
      const pcm16 = new Int16Array(inputData.length);
      for (let i = 0; i < inputData.length; i++) {
        pcm16[i] = Math.max(-1, Math.min(1, inputData[i])) * 0x7FFF;
      }

      // Send to Live API
      const base64 = btoa(String.fromCharCode(...new Uint8Array(pcm16.buffer)));
      sessionPromise.then(session => {
        session.sendRealtimeInput({
          audio: { data: base64, mimeType: 'audio/pcm;rate=16000' }
        });
      });
    };

    source.connect(processor);
    processor.connect(context.destination);
  };

  const queueAudio = (base64Data: string) => {
    const binary = atob(base64Data);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    const pcm16 = new Int16Array(bytes.buffer);
    audioQueueRef.current.push(pcm16);
    if (!isPlayingRef.current) {
      processAudioQueue();
    }
  };

  const processAudioQueue = async () => {
    if (audioQueueRef.current.length === 0) {
      isPlayingRef.current = false;
      return;
    }
    isPlayingRef.current = true;
    const pcm16 = audioQueueRef.current.shift()!;
    
    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    }
    const context = audioContextRef.current;
    
    // Ensure context is running
    if (context.state === 'suspended') {
      await context.resume();
    }

    const float32 = new Float32Array(pcm16.length);
    for (let i = 0; i < pcm16.length; i++) {
      float32[i] = pcm16[i] / 0x7FFF;
    }

    const buffer = context.createBuffer(1, float32.length, 24000);
    buffer.getChannelData(0).set(float32);
    const source = context.createBufferSource();
    source.buffer = buffer;
    source.connect(context.destination);
    source.onended = () => processAudioQueue();
    source.start();
  };

  const saveToHistory = () => {
    if (liveTranscription || aiTranscription) {
      const newHistoryItem: Message = {
        id: Date.now().toString(),
        role: 'assistant',
        content: `Live Session: ${aiTranscription || "Voice interaction"}`,
        type: 'voice'
      };
      setHistory(prev => [newHistoryItem, ...prev]);
    }
  };

  const stopLiveMode = () => {
    saveToHistory();
    liveSessionRef.current?.close();
    liveSessionRef.current = null;
    processorRef.current?.disconnect();
    processorRef.current = null;
    streamRef.current?.getTracks().forEach(track => track.stop());
    streamRef.current = null;
    setIsLiveMode(false);
    setMicVolume(0);
    setLiveTranscription('');
    setAiTranscription('');
    setLiveStatus('listening');
    audioQueueRef.current = [];
    isPlayingRef.current = false;
    if (view === 'live') setView('landing');
  };

  // --- Content Generation Logic ---

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    Array.from(files).forEach(file => {
      const reader = new FileReader();
      reader.onloadend = () => setSelectedImages(prev => [...prev, reader.result as string]);
      reader.readAsDataURL(file);
    });
  };

  const generateImage = async (prompt: string) => {
    setIsGeneratingImage(true);
    try {
      // Check for API key selection for premium models
      if (!(await (window as any).aistudio.hasSelectedApiKey())) {
        await (window as any).aistudio.openSelectKey();
      }

      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-pro-image-preview',
        contents: { parts: [{ text: prompt }] },
        config: {
          imageConfig: {
            aspectRatio: "1:1",
            imageSize: imageSize
          }
        },
      });

      let imageUrl = '';
      for (const part of response.candidates?.[0]?.content?.parts || []) {
        if (part.inlineData) {
          imageUrl = `data:image/png;base64,${part.inlineData.data}`;
          break;
        }
      }

      if (imageUrl) {
        setMessages(prev => [...prev, {
          id: Date.now().toString(),
          role: 'assistant',
          content: `Generated image for: "${prompt}"`,
          images: [imageUrl],
          type: 'image'
        }]);
      }
    } catch (err) {
      console.error("Image Gen Error:", err);
    } finally {
      setIsGeneratingImage(false);
    }
  };

  const speak = async (text: string) => {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text: `Say: ${text}` }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: selectedVoice },
            },
          },
        },
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (base64Audio) {
        queueAudio(base64Audio);
      }
    } catch (err) {
      console.error("TTS Error:", err);
    }
  };

  const handleSubmit = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() && selectedImages.length === 0) return;
    if (isTyping) return;

    // Detect image generation command
    if (input.toLowerCase().startsWith('/image ')) {
      const prompt = input.slice(7);
      setInput('');
      await generateImage(prompt);
      return;
    }

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      images: selectedImages.length > 0 ? [...selectedImages] : undefined,
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setSelectedImages([]);
    setIsTyping(true);

    const assistantMessageId = (Date.now() + 1).toString();
    setMessages(prev => [...prev, {
      id: assistantMessageId,
      role: 'assistant',
      content: '',
      isStreaming: true,
      isThinking: isThinkingMode
    }]);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      
      const modelName = isThinkingMode ? "gemini-3.1-pro-preview" : "gemini-3-flash-preview";
      const tools: any[] = [];
      if (useSearch) tools.push({ googleSearch: {} });
      if (useMaps) tools.push({ googleMaps: {} });

      const parts: any[] = [{ text: input || "Analyze this image" }];
      if (userMessage.images) {
        userMessage.images.forEach(img => {
          parts.push({
            inlineData: {
              data: img.split(',')[1],
              mimeType: img.split(';')[0].split(':')[1]
            }
          });
        });
      }

      const streamResponse = await ai.models.generateContentStream({
        model: modelName,
        contents: { parts },
        config: {
          tools: tools.length > 0 ? tools : undefined,
          thinkingConfig: isThinkingMode ? { thinkingLevel: ThinkingLevel.HIGH } : undefined,
        }
      });

      let fullText = '';
      for await (const chunk of streamResponse) {
        const textChunk = (chunk as GenerateContentResponse).text;
        if (textChunk) {
          fullText += textChunk;
          setMessages(prev => prev.map(msg => 
            msg.id === assistantMessageId ? { ...msg, content: fullText } : msg
          ));
        }
      }

      setMessages(prev => prev.map(msg => 
        msg.id === assistantMessageId ? { ...msg, isStreaming: false } : msg
      ));

      // Speak the response
      if (fullText) {
        await speak(fullText);
      }
    } catch (error) {
      console.error("AI Error:", error);
      setMessages(prev => prev.map(msg => 
        msg.id === assistantMessageId ? { ...msg, content: "Error processing request.", isStreaming: false } : msg
      ));
    } finally {
      setIsTyping(false);
    }
  };

  // --- UI Views ---

  if (showIntro) return <IntroAnimation onComplete={() => setShowIntro(false)} />;

  return (
    <div className="min-h-screen bg-white dark:bg-black text-zinc-900 dark:text-zinc-100 selection:bg-blue-500/30 relative overflow-hidden font-sans">
      {/* Enhanced Aura Waves Background */}
      <div className="aura-container">
        <div className="aura-wave" />
        <div className="aura-wave" />
        <div className="aura-wave" />
      </div>
      
      <AboutModal isOpen={showAbout} onClose={() => setShowAbout(false)} />
      <HistoryModal isOpen={showHistory} onClose={() => setShowHistory(false)} history={history} />
      <SettingsModal 
        isOpen={showSettings} 
        onClose={() => setShowSettings(false)} 
        selectedVoice={selectedVoice}
        onVoiceChange={setSelectedVoice}
        speechSpeed={speechSpeed}
        onSpeedChange={setSpeechSpeed}
      />

      {view === 'landing' ? (
        <div className="min-h-screen flex flex-col items-center justify-center p-6 text-center relative z-10">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="max-w-4xl w-full space-y-12"
          >
            <motion.div 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="inline-flex items-center gap-2 px-5 py-2 rounded-full bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 backdrop-blur-2xl mb-4 shadow-2xl"
            >
              <Sparkles className="w-4 h-4 text-blue-400 animate-pulse" />
              <span className="text-[10px] font-black tracking-[0.3em] uppercase text-zinc-600 dark:text-zinc-400">Intelligence Redefined</span>
            </motion.div>
            
            <div className="space-y-4">
              <motion.h1 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="text-7xl sm:text-9xl font-black tracking-tighter text-zinc-900 dark:text-white leading-none"
              >
                AURA <span className="bg-clip-text text-transparent bg-gradient-to-b from-white via-zinc-400 to-zinc-600">AI</span>
              </motion.h1>
              <motion.p 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.6 }}
                className="text-lg sm:text-xl text-zinc-600 dark:text-zinc-400 max-w-2xl mx-auto leading-relaxed font-medium"
              >
                Experience the next evolution of human-AI interaction. 
                Fast, beautiful, and profoundly capable.
              </motion.p>
            </div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8 }}
              className="flex flex-col sm:flex-row items-center justify-center gap-6 pt-4"
            >
              <button 
                onClick={() => setView('conversation')}
                className="group relative px-10 py-5 bg-zinc-900 dark:bg-white text-white dark:text-black font-black rounded-2xl flex items-center gap-3 hover:scale-105 active:scale-95 transition-all shadow-[0_0_50px_rgba(0,0,0,0.15)] dark:shadow-[0_0_50px_rgba(255,255,255,0.15)] overflow-hidden"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-blue-400/20 to-purple-400/20 opacity-0 group-hover:opacity-100 transition-opacity" />
                <span className="relative z-10">Start Conversation</span>
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform relative z-10" />
              </button>
              <button 
                onClick={() => setShowAbout(true)}
                className="px-10 py-5 bg-zinc-100/40 dark:bg-zinc-900/40 border border-black/10 dark:border-zinc-800/50 text-zinc-900 dark:text-white font-black rounded-2xl hover:bg-zinc-200/60 dark:hover:bg-zinc-800/60 transition-all backdrop-blur-2xl hover:border-black/20 dark:hover:border-zinc-700"
              >
                About Developer
              </button>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1 }}
              className="grid grid-cols-2 md:grid-cols-4 gap-8 pt-20 max-w-3xl mx-auto"
            >
              {[
                { label: "Ultra Fast", icon: Zap, color: "text-blue-400" },
                { label: "Deep Logic", icon: Brain, color: "text-purple-400" },
                { label: "Visual Art", icon: ImageIcon, color: "text-pink-400" },
                { label: "Real-time", icon: Search, color: "text-emerald-400" }
              ].map((feature) => (
                <div key={feature.label} className="flex flex-col items-center gap-3 group cursor-default">
                  <div className="w-12 h-12 rounded-2xl bg-zinc-100/50 dark:bg-zinc-900/50 border border-black/10 dark:border-zinc-800/50 flex items-center justify-center group-hover:scale-110 group-hover:border-black/20 dark:group-hover:border-zinc-700 transition-all duration-500">
                    <feature.icon className={cn("w-5 h-5", feature.color)} />
                  </div>
                  <span className="text-[10px] font-black uppercase tracking-[0.2em] text-zinc-500 group-hover:text-zinc-900 dark:group-hover:text-zinc-300 transition-colors">{feature.label}</span>
                </div>
              ))}
            </motion.div>
          </motion.div>
          
          <div className="absolute bottom-8 left-0 right-0 flex justify-center opacity-20">
            <p className="text-[10px] font-black uppercase tracking-[0.5em]">AURA Intelligence v1.0</p>
          </div>
        </div>
      ) : view === 'conversation' ? (
        <div className="h-screen flex flex-col max-w-6xl mx-auto relative z-10">
          {/* Header */}
          <header className="px-6 py-5 flex items-center justify-between border-b border-black/5 dark:border-white/5 backdrop-blur-3xl sticky top-0 z-50">
            <div className="flex items-center gap-6">
              <button 
                onClick={() => setView('landing')}
                className="group p-2.5 hover:bg-black/5 dark:hover:bg-white/5 rounded-2xl transition-all border border-transparent hover:border-black/10 dark:hover:border-white/10"
              >
                <Home className="w-5 h-5 text-zinc-500 group-hover:text-zinc-900 dark:group-hover:text-zinc-300" />
              </button>
              <button 
                onClick={() => setShowHistory(true)}
                className="group p-2.5 hover:bg-black/5 dark:hover:bg-white/5 rounded-2xl transition-all border border-transparent hover:border-black/10 dark:hover:border-white/10"
              >
                <History className="w-5 h-5 text-zinc-500 group-hover:text-zinc-900 dark:group-hover:text-zinc-300" />
              </button>
              <button 
                onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                className="group p-2.5 hover:bg-black/5 dark:hover:bg-white/5 rounded-2xl transition-all border border-transparent hover:border-black/10 dark:hover:border-white/10"
              >
                {theme === 'dark' ? (
                  <Sun className="w-5 h-5 text-zinc-500 group-hover:text-zinc-900 dark:group-hover:text-zinc-300" />
                ) : (
                  <Moon className="w-5 h-5 text-zinc-500 group-hover:text-zinc-900 dark:group-hover:text-zinc-300" />
                )}
              </button>
              <div className="flex flex-col">
                <h2 className="text-xl font-black tracking-tighter text-zinc-900 dark:text-white aura-text-glow">AURA</h2>
                <div className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-pulse shadow-[0_0_10px_rgba(59,130,246,0.5)]" />
                  <span className="text-[9px] font-black text-zinc-500 uppercase tracking-[0.2em]">Neural Link Active</span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="hidden md:flex items-center gap-2 p-1.5 bg-black/5 dark:bg-black/40 border border-black/5 dark:border-white/5 rounded-2xl backdrop-blur-xl">
                <button 
                  onClick={() => setIsThinkingMode(!isThinkingMode)}
                  className={cn(
                    "px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-2 border border-transparent",
                    isThinkingMode 
                      ? "bg-purple-500/10 text-purple-400 border-purple-500/20 shadow-[0_0_20px_rgba(168,85,247,0.1)]" 
                      : "text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-300 hover:bg-black/5 dark:hover:bg-white/5"
                  )}
                >
                  <Brain className="w-3.5 h-3.5" />
                  Thinking
                </button>
                <button 
                  onClick={() => { setView('live'); startLiveMode(); }}
                  className="px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-2 border border-transparent text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-300 hover:bg-black/5 dark:hover:bg-white/5"
                >
                  <Zap className="w-3.5 h-3.5" />
                  Live
                </button>
              </div>
              <button 
                onClick={() => setShowSettings(true)}
                className="p-2.5 text-zinc-500 hover:text-zinc-900 dark:hover:text-white transition-all hover:bg-black/5 dark:hover:bg-white/5 rounded-2xl border border-transparent hover:border-black/10 dark:hover:border-white/10"
              >
                <Settings className="w-5 h-5" />
              </button>
            </div>
          </header>

          {/* Chat Area */}
          <main className="flex-1 overflow-y-auto px-4 md:px-12 py-12 space-y-12 scrollbar-hide">
            {messages.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center space-y-16">
                <motion.div 
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="w-32 h-32 bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-[3rem] flex items-center justify-center shadow-2xl backdrop-blur-3xl"
                >
                  <Bot className="w-16 h-16 text-zinc-600 dark:text-zinc-400" />
                </motion.div>
                <div className="space-y-6 max-w-2xl">
                  <h3 className="text-4xl font-black tracking-tight text-zinc-900 dark:text-white">How can I assist you today?</h3>
                  <div className="flex flex-wrap justify-center gap-3">
                    {[
                      { text: "Create a futuristic city", icon: ImageIcon },
                      { text: "Explain quantum physics", icon: Brain },
                      { text: "Write a modern landing page", icon: Sparkles },
                      { text: "Latest AI breakthroughs", icon: Search }
                    ].map(suggestion => (
                      <button 
                        key={suggestion.text} 
                        onClick={() => setInput(suggestion.text)}
                        className="px-6 py-3 bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-2xl text-sm font-bold text-zinc-600 dark:text-zinc-400 hover:bg-black/10 dark:hover:bg-white/10 hover:border-black/20 dark:hover:border-white/20 hover:text-zinc-900 dark:hover:text-white transition-all flex items-center gap-3"
                      >
                        <suggestion.icon className="w-4 h-4" />
                        {suggestion.text}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-16 max-w-5xl mx-auto">
                {messages.map((message) => (
                  <motion.div
                    key={message.id}
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={cn(
                      "flex gap-6 md:gap-10",
                      message.role === 'user' ? "flex-row-reverse" : "flex-row"
                    )}
                  >
                    <div className={cn(
                      "w-12 h-12 md:w-14 md:h-14 rounded-2xl flex items-center justify-center shrink-0 shadow-2xl border transition-all duration-500",
                      message.role === 'user' 
                        ? "bg-zinc-100 dark:bg-zinc-900 border-black/10 dark:border-zinc-800 text-zinc-500" 
                        : "bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600 text-white border-black/10 dark:border-white/20 aura-text-glow"
                    )}>
                      {message.role === 'user' ? <User className="w-7 h-7" /> : <Bot className="w-7 h-7" />}
                    </div>
                    
                    <div className={cn(
                      "flex flex-col space-y-6 max-w-[90%] md:max-w-[80%]",
                      message.role === 'user' ? "items-end" : "items-start"
                    )}>
                      {message.images && (
                        <div className="flex flex-wrap gap-4">
                          {message.images.map((img, i) => (
                            <motion.div 
                              key={i}
                              whileHover={{ scale: 1.02, y: -5 }}
                              className="relative group rounded-3xl overflow-hidden shadow-2xl border border-black/10 dark:border-white/10"
                            >
                              <img 
                                src={img} 
                                alt="Content" 
                                className="max-w-full md:max-w-2xl object-cover"
                                referrerPolicy="no-referrer"
                              />
                              <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-[2px]">
                                <Maximize2 className="w-8 h-8 text-white" />
                              </div>
                            </motion.div>
                          ))}
                        </div>
                      )}
                      
                      <div className={cn(
                        "px-8 py-6 rounded-[2.5rem] text-lg leading-relaxed shadow-2xl glass-panel relative group",
                        message.role === 'user' ? "bg-black/5 dark:bg-white/5 border-black/10 dark:border-white/10" : "bg-white/40 dark:bg-black/40 border-black/5 dark:border-white/5"
                      )}>
                        {message.isThinking && message.role === 'assistant' && (
                          <div className="flex items-center gap-3 mb-4 text-[10px] font-black uppercase tracking-[0.3em] text-purple-400">
                            <div className="w-1.5 h-1.5 bg-purple-500 rounded-full animate-ping" />
                            Deep Reasoning Active
                          </div>
                        )}
                        <div className="markdown-body">
                          <ReactMarkdown>{message.content}</ReactMarkdown>
                          {message.isStreaming && (
                            <motion.span 
                              animate={{ opacity: [0, 1, 0], scale: [1, 1.2, 1] }}
                              transition={{ duration: 1, repeat: Infinity }}
                              className="inline-block w-2.5 h-6 ml-2 bg-blue-500 align-middle rounded-full shadow-[0_0_15px_rgba(59,130,246,0.5)]" 
                            />
                          )}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))}
                <div ref={messagesEndRef} />
              </div>
            )}
          </main>

          {/* Input Area */}
          <footer className="p-6 md:p-10">
            <div className="max-w-5xl mx-auto space-y-6">
              {/* Toolbar */}
              <div className="flex items-center justify-between px-4">
                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => setUseSearch(!useSearch)}
                    className={cn(
                      "px-4 py-2 rounded-2xl transition-all flex items-center gap-2 text-[10px] font-black uppercase tracking-widest border",
                      useSearch 
                        ? "bg-blue-500/10 text-blue-400 border-blue-500/20 shadow-[0_0_15px_rgba(59,130,246,0.1)]" 
                        : "text-zinc-500 border-transparent hover:text-zinc-900 dark:hover:text-zinc-300 hover:bg-black/5 dark:hover:bg-white/5"
                    )}
                  >
                    <Search className="w-3.5 h-3.5" />
                    <span className="hidden md:inline">Search</span>
                  </button>
                  <button 
                    onClick={() => setUseMaps(!useMaps)}
                    className={cn(
                      "px-4 py-2 rounded-2xl transition-all flex items-center gap-2 text-[10px] font-black uppercase tracking-widest border",
                      useMaps 
                        ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20 shadow-[0_0_15px_rgba(16,185,129,0.1)]" 
                        : "text-zinc-500 border-transparent hover:text-zinc-900 dark:hover:text-zinc-300 hover:bg-black/5 dark:hover:bg-white/5"
                    )}
                  >
                    <MapPin className="w-3.5 h-3.5" />
                    <span className="hidden md:inline">Maps</span>
                  </button>
                  <div className="w-px h-5 bg-black/10 dark:bg-white/10 mx-2" />
                  <div className="relative group">
                    <button className="px-4 py-2 text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-300 flex items-center gap-2 text-[10px] font-black uppercase tracking-widest transition-all hover:bg-black/5 dark:hover:bg-white/5 rounded-2xl">
                      <ImageIcon className="w-3.5 h-3.5" />
                      <span className="hidden md:inline">{imageSize} Image</span>
                      <ChevronDown className="w-3 h-3" />
                    </button>
                    <div className="absolute bottom-full left-0 mb-3 hidden group-hover:block bg-white dark:bg-zinc-900 border border-black/10 dark:border-white/10 rounded-2xl overflow-hidden shadow-2xl backdrop-blur-3xl min-w-[120px]">
                      {['1K', '2K', '4K'].map(size => (
                        <button 
                          key={size}
                          onClick={() => setImageSize(size as any)}
                          className={cn(
                            "w-full px-5 py-3 text-left text-[10px] font-black uppercase tracking-widest transition-colors",
                            imageSize === size ? "bg-blue-500/10 text-blue-400" : "text-zinc-500 hover:bg-black/5 dark:hover:bg-white/5 hover:text-zinc-900 dark:hover:text-white"
                          )}
                        >
                          {size} Resolution
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {isLiveMode && (
                  <div className="flex items-center gap-3 px-5 py-2 bg-blue-500/10 text-blue-400 rounded-full border border-blue-500/20 shadow-[0_0_20px_rgba(59,130,246,0.1)]">
                    <div className="w-2 h-2 bg-blue-500 rounded-full animate-ping" />
                    <span className="text-[10px] font-black uppercase tracking-[0.2em]">Listening</span>
                  </div>
                )}
              </div>

              {/* Input Box */}
              <div className="relative">
                <AnimatePresence>
                  {selectedImages.length > 0 && (
                    <motion.div 
                      initial={{ opacity: 0, y: 20, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 20, scale: 0.95 }}
                      className="absolute bottom-full mb-6 flex flex-wrap gap-3 p-3 bg-white/60 dark:bg-black/60 backdrop-blur-3xl border border-black/10 dark:border-white/10 rounded-3xl shadow-2xl"
                    >
                      {selectedImages.map((img, i) => (
                        <div key={i} className="relative group">
                          <img src={img} alt="Preview" className="w-20 h-20 object-cover rounded-2xl border border-black/5 dark:border-white/5" referrerPolicy="no-referrer" />
                          <button 
                            onClick={() => setSelectedImages(prev => prev.filter((_, idx) => idx !== i))} 
                            className="absolute -top-2 -right-2 p-1.5 bg-red-500 text-white rounded-full shadow-xl opacity-0 group-hover:opacity-100 transition-all hover:scale-110 active:scale-90"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}
                    </motion.div>
                  )}
                </AnimatePresence>

                <div className="relative group">
                  <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-[3rem] opacity-30 group-focus-within:opacity-100 blur transition duration-500"></div>
                  <form 
                    onSubmit={handleSubmit}
                    className="relative flex items-end gap-3 p-3 bg-white/90 dark:bg-zinc-950/90 backdrop-blur-3xl rounded-[2.5rem] transition-all duration-500 shadow-[0_8px_30px_rgb(0,0,0,0.12)] dark:shadow-[0_8px_30px_rgb(0,0,0,0.5)]"
                  >
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="p-5 text-zinc-500 hover:text-zinc-900 dark:hover:text-white transition-all rounded-3xl hover:bg-black/5 dark:hover:bg-white/5"
                    >
                      <Paperclip className="w-7 h-7" />
                    </button>
                    <input type="file" multiple accept="image/*" className="hidden" ref={fileInputRef} onChange={handleImageUpload} />
                    
                    <textarea
                      value={input}
                      onChange={(e) => setInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                          e.preventDefault();
                          handleSubmit();
                        }
                      }}
                      placeholder={isLiveMode ? "AURA is listening..." : "Ask AURA anything..."}
                      rows={1}
                      className="flex-1 bg-transparent border-0 border-transparent outline-none focus:outline-none ring-0 focus:ring-0 shadow-none focus:shadow-none text-zinc-900 dark:text-white py-5 px-3 resize-none max-h-64 text-lg font-medium placeholder:text-zinc-400 dark:placeholder:text-zinc-600"
                      style={{ height: 'auto' }}
                      onInput={(e) => {
                        const target = e.target as HTMLTextAreaElement;
                        target.style.height = 'auto';
                        target.style.height = `${target.scrollHeight}px`;
                      }}
                    />

                    <button
                      type="submit"
                      disabled={isTyping || isGeneratingImage || (!input.trim() && selectedImages.length === 0)}
                      className={cn(
                        "p-5 rounded-[2rem] transition-all flex items-center justify-center shadow-2xl border border-transparent",
                        isTyping || isGeneratingImage || (!input.trim() && selectedImages.length === 0)
                          ? "bg-zinc-100 dark:bg-zinc-900 text-zinc-400 dark:text-zinc-700"
                          : "bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600 text-white hover:scale-105 active:scale-95 shadow-[0_0_30px_rgba(168,85,247,0.4)]"
                      )}
                    >
                      {isTyping || isGeneratingImage ? <Loader2 className="w-7 h-7 animate-spin" /> : <Send className="w-7 h-7" />}
                    </button>
                  </form>
                </div>
              </div>
              <p className="text-[9px] text-center text-zinc-700 font-black uppercase tracking-[0.6em] pt-2">
                AURA Intelligence • Developed by Monish
              </p>
            </div>
          </footer>
        </div>
      ) : (
        <div className="h-screen flex flex-col items-center justify-center relative z-10">
          <header className="absolute top-0 left-0 right-0 px-6 py-5 flex items-center justify-between border-b border-black/5 dark:border-white/5 backdrop-blur-3xl z-50">
            <div className="flex items-center gap-6">
              <button 
                onClick={stopLiveMode}
                className="group p-2.5 hover:bg-black/5 dark:hover:bg-white/5 rounded-2xl transition-all border border-transparent hover:border-black/10 dark:hover:border-white/10"
              >
                <X className="w-5 h-5 text-zinc-500 group-hover:text-zinc-900 dark:group-hover:text-zinc-300" />
              </button>
              <div className="flex flex-col">
                <h2 className="text-xl font-black tracking-tighter text-zinc-900 dark:text-white aura-text-glow">AURA LIVE</h2>
                <div className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-pulse shadow-[0_0_10px_rgba(59,130,246,0.5)]" />
                  <span className="text-[9px] font-black text-zinc-500 uppercase tracking-[0.2em]">Voice Link Active</span>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <button 
                onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                className="p-2.5 text-zinc-500 hover:text-zinc-900 dark:hover:text-white transition-all hover:bg-black/5 dark:hover:bg-white/5 rounded-2xl border border-transparent hover:border-black/10 dark:hover:border-white/10"
              >
                {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
              </button>
              <button 
                onClick={() => setShowSettings(true)}
                className="p-2.5 text-zinc-500 hover:text-zinc-900 dark:hover:text-white transition-all hover:bg-black/5 dark:hover:bg-white/5 rounded-2xl border border-transparent hover:border-black/10 dark:hover:border-white/10"
              >
                <Settings className="w-5 h-5" />
              </button>
            </div>
          </header>

          <main className="flex-1 w-full flex flex-col items-center justify-center p-6 space-y-8">
            <div className="relative w-full max-w-2xl flex flex-col items-center">
              <LiveVisualizer isActive={isLiveMode} volume={micVolume} status={liveStatus} />
              
              {/* Transcription Overlay */}
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                <AnimatePresence mode="wait">
                  {liveTranscription && (
                    <motion.div
                      key="user-transcription"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="bg-white/60 dark:bg-black/60 backdrop-blur-2xl px-8 py-4 rounded-3xl border border-black/10 dark:border-white/10 text-zinc-900 dark:text-white text-lg font-bold max-w-lg text-center mb-4 shadow-[0_0_50px_rgba(0,0,0,0.5)]"
                    >
                      {liveTranscription}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>
            
            <div className="text-center space-y-6 max-w-2xl w-full">
              <div className="space-y-2">
                <h3 className="text-4xl font-black tracking-tight text-zinc-900 dark:text-white aura-text-glow">
                  {liveStatus === 'listening' && "Listening..."}
                  {liveStatus === 'thinking' && "Thinking..."}
                  {liveStatus === 'speaking' && "AURA is speaking"}
                  {!isLiveMode && "Connecting..."}
                </h3>
                <div className="flex justify-center gap-1">
                  <motion.div 
                    animate={{ scale: liveStatus === 'listening' ? [1, 1.5, 1] : 1 }}
                    transition={{ repeat: Infinity, duration: 2 }}
                    className={cn("w-1.5 h-1.5 rounded-full", liveStatus === 'listening' ? "bg-blue-500 shadow-[0_0_10px_rgba(59,130,246,0.5)]" : "bg-zinc-300 dark:bg-zinc-800")} 
                  />
                  <motion.div 
                    animate={{ scale: liveStatus === 'thinking' ? [1, 1.5, 1] : 1 }}
                    transition={{ repeat: Infinity, duration: 1.5 }}
                    className={cn("w-1.5 h-1.5 rounded-full", liveStatus === 'thinking' ? "bg-purple-500 shadow-[0_0_10px_rgba(168,85,247,0.5)]" : "bg-zinc-300 dark:bg-zinc-800")} 
                  />
                  <motion.div 
                    animate={{ scale: liveStatus === 'speaking' ? [1, 1.5, 1] : 1 }}
                    transition={{ repeat: Infinity, duration: 1 }}
                    className={cn("w-1.5 h-1.5 rounded-full", liveStatus === 'speaking' ? "bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)]" : "bg-zinc-300 dark:bg-zinc-800")} 
                  />
                </div>
              </div>

              <AnimatePresence>
                {aiTranscription && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="p-8 bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-[2.5rem] backdrop-blur-3xl shadow-2xl relative group"
                  >
                    <div className="absolute -top-3 left-8 px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded-full text-[8px] font-black uppercase tracking-widest text-emerald-400">
                      AI Transcription
                    </div>
                    <p className="text-xl text-zinc-800 dark:text-zinc-200 leading-relaxed font-medium italic">
                      "{aiTranscription}"
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>

              {!aiTranscription && (
                <p className="text-zinc-500 text-sm font-medium max-w-xs mx-auto">
                  Speak naturally. AURA will respond with its voice and transcription.
                </p>
              )}
            </div>

            <div className="flex items-center gap-4">
              {liveStatus === 'speaking' && (
                <button 
                  onClick={() => {
                    audioQueueRef.current = [];
                    isPlayingRef.current = false;
                    setLiveStatus('listening');
                  }}
                  className="px-8 py-5 bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 text-zinc-900 dark:text-white font-black rounded-[2rem] hover:bg-black/10 dark:hover:bg-white/10 transition-all uppercase tracking-[0.2em] text-xs flex items-center gap-3"
                >
                  <MicOff className="w-4 h-4" />
                  Interrupt
                </button>
              )}
              <button 
                onClick={stopLiveMode}
                className="group px-12 py-5 bg-red-500/10 border border-red-500/20 text-red-500 font-black rounded-[2rem] hover:bg-red-500/20 transition-all uppercase tracking-[0.2em] text-xs flex items-center gap-3"
              >
                <X className="w-4 h-4 group-hover:rotate-90 transition-transform" />
                End Session
              </button>
            </div>
          </main>

          <footer className="absolute bottom-8 left-0 right-0 flex justify-center opacity-20">
            <p className="text-[10px] font-black uppercase tracking-[0.5em]">AURA Neural Voice Engine</p>
          </footer>
        </div>
      )}
    </div>
  );
}
